(() => {
  "use strict";

  const QUESTIONS = [
    // Bahagian A - 15 objektif
    { type: "mc", q: "Kata majmuk yang betul ialah ...", options: ["hujan panas", "hujanpanas"], answer: 0 },
    { type: "mc", q: "Pilih kata majmuk yang terdapat dalam nota.", options: ["tengah hari", "tengahari"], answer: 0 },
    { type: "mc", q: "Pasangan kata majmuk yang betul ialah ...", options: ["kereta api", "keretaapi"], answer: 0 },
    { type: "mc", q: "Kata majmuk yang betul ialah ...", options: ["jam dinding", "jamdinding"], answer: 0 },
    { type: "mc", q: "Pilih ejaan yang betul.", options: ["balai polis", "balaipolis"], answer: 0 },
    { type: "mc", q: "Kenderaan yang digunakan oleh pasukan bomba ialah ...", options: ["kereta bomba", "keretabomba"], answer: 0 },
    { type: "mc", q: "Pilih kata majmuk yang betul.", options: ["pasar malam", "pasarmalam"], answer: 0 },
    { type: "mc", q: "Kata majmuk yang betul ialah ...", options: ["jalan raya", "jalanraya"], answer: 0 },
    { type: "mc", q: "Pilih ejaan yang betul.", options: ["kasut sukan", "kasutsukan"], answer: 0 },
    { type: "mc", q: "Kata majmuk bagi tempat penginapan tetamu ialah ...", options: ["rumah tamu", "rumahtamu"], answer: 0 },
    { type: "mc", q: "Kata majmuk bebas ditulis ...", options: ["secara terpisah", "secara bercantum"], answer: 0 },
    { type: "mc", q: "Kata majmuk bebas terbentuk daripada ...", options: ["dua kata dasar", "satu kata dasar"], answer: 0 },
    { type: "mc", q: "Kedua-dua perkataan dalam kata majmuk bebas membawa ...", options: ["makna tersendiri", "makna yang sama sahaja"], answer: 0 },
    { type: "mc", q: "Antara berikut, yang manakah kata majmuk bebas?", options: ["kereta api", "keretaapi"], answer: 0 },
    { type: "mc", q: "Antara berikut, yang manakah kata majmuk bebas?", options: ["rumah tamu", "rumahtamu"], answer: 0 },

    // Bahagian B - 10 subjektif
    { type: "text", q: "Lengkapkan ayat: Kami menikmati ______ yang turun pada waktu tengah hari.", answer: "hujan panas" },
    { type: "text", q: "Lengkapkan ayat: Ayah pergi ke bandar pada ______.", answer: "tengah hari" },
    { type: "text", q: "Lengkapkan ayat: Kami menaiki ______ untuk pergi ke bandar.", answer: "kereta api" },
    { type: "text", q: "Lengkapkan ayat: ______ di ruang tamu menunjukkan pukul tiga.", answer: "jam dinding" },
    { type: "text", q: "Lengkapkan ayat: Ayah pergi ke ______ untuk membuat laporan.", answer: "balai polis" },
    { type: "text", q: "Lengkapkan ayat: Pasukan penyelamat menaiki ______ ke tempat kejadian.", answer: "kereta bomba" },
    { type: "text", q: "Lengkapkan ayat: Ibu membeli sayur di ______.", answer: "pasar malam" },
    { type: "text", q: "Lengkapkan ayat: Bas itu melalui ______ yang sibuk.", answer: "jalan raya" },
    { type: "text", q: "Lengkapkan ayat: Saya memakai ______ ketika bermain bola.", answer: "kasut sukan" },
    { type: "text", q: "Lengkapkan ayat: Nenek tinggal di ______ semasa datang melawat kami.", answer: "rumah tamu" }
  ];

  const $ = (selector) => document.querySelector(selector);
  const startScreen = $("#startScreen");
  const quizScreen = $("#quizScreen");
  const resultScreen = $("#resultScreen");
  const studentName = $("#studentName");
  const nameError = $("#nameError");
  const questionArea = $("#questionArea");
  const feedback = $("#feedback");
  const nextBtn = $("#nextBtn");
  const prevBtn = $("#prevBtn");
  const timerEl = $("#timer");
  const scoreEl = $("#score");
  const questionNoEl = $("#questionNo");
  const starsEl = $("#stars");
  const progressBar = $("#progressBar");
  const leaderboardEl = $("#leaderboard");

  let player = "";
  let current = 0;
  let score = 0;
  let correctCount = 0;
  let stars = 0;
  let timeLeft = 15 * 60;
  let timerId = null;
  let answered = false;

  // Static GitHub Pages cannot share data between different pupils/devices.
  // localStorage therefore stores the leaderboard only on the current browser.
  const BOARD_KEY = "kataMajmukLeaderboardV1";

  const starterBoard = [
    { name: "Juara Bahasa", score: 1200 },
    { name: "Bintang Cilik", score: 1000 },
    { name: "Bijak Kata", score: 850 }
  ];

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[char]));
  }

  function normalise(value) {
    return value.trim().toLowerCase().replace(/\s+/g, " ");
  }

  function getBoard() {
    try {
      const saved = JSON.parse(localStorage.getItem(BOARD_KEY));
      return Array.isArray(saved) ? saved : starterBoard.slice();
    } catch {
      return starterBoard.slice();
    }
  }

  function saveBoard(board) {
    try {
      localStorage.setItem(BOARD_KEY, JSON.stringify(board));
    } catch {
      // The quiz remains fully usable if browser storage is unavailable.
    }
  }

  function renderLeaderboard() {
    const board = getBoard()
      .filter(item => item && typeof item.name === "string" && Number.isFinite(item.score))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);

    leaderboardEl.innerHTML = board.map((item, index) => `
      <li>
        <div class="leader-row">
          <span>${["🥇", "🥈", "🥉"][index] || "🏅"} ${escapeHTML(item.name)}</span>
          <strong>${item.score}</strong>
        </div>
      </li>
    `).join("");
  }

  function updateHeader() {
    scoreEl.textContent = score;
    questionNoEl.textContent = `${current + 1}/${QUESTIONS.length}`;
    starsEl.textContent = `${stars} ⭐`;
    progressBar.style.width = `${Math.round((current / QUESTIONS.length) * 100)}%`;
  }

  function renderQuestion() {
    const item = QUESTIONS[current];
    answered = false;
    feedback.className = "feedback";
    feedback.textContent = "";
    nextBtn.disabled = true;

    $("#sectionChip").textContent = current < 15 ? "Bahagian A • Objektif" : "Bahagian B • Subjektif";
    updateHeader();

    if (item.type === "mc") {
      questionArea.innerHTML = `
        <span class="question-number">Soalan ${current + 1}</span>
        <div class="question-text">${escapeHTML(item.q)}</div>
        <div class="option-grid">
          ${item.options.map((option, index) => `
            <button class="option" type="button" data-option="${index}">
              ${String.fromCharCode(65 + index)}. ${escapeHTML(option)}
            </button>
          `).join("")}
        </div>
      `;

      questionArea.querySelectorAll("[data-option]").forEach(button => {
        button.addEventListener("click", () => checkMC(Number(button.dataset.option)));
      });
    } else {
      questionArea.innerHTML = `
        <span class="question-number">Soalan ${current + 1}</span>
        <div class="question-text">${escapeHTML(item.q)}</div>
        <label for="textAnswer"><b>✏️ Jawapan kamu:</b></label>
        <input id="textAnswer" class="text-answer" maxlength="40"
               autocomplete="off" placeholder="Taip kata majmuk di sini">
        <button id="checkText" class="btn btn-primary" type="button" style="margin-top:10px">
          Semak Jawapan ✓
        </button>
      `;

      $("#checkText").addEventListener("click", checkText);
      $("#textAnswer").addEventListener("keydown", (event) => {
        if (event.key === "Enter") checkText();
      });
    }

    prevBtn.disabled = current === 0;
  }

  function applyScore(isCorrect) {
    if (isCorrect) {
      score += 100;
      correctCount++;
      stars++;
    } else {
      score -= 50;
    }
    updateHeader();
  }

  function checkMC(choice) {
    if (answered) return;
    answered = true;

    const item = QUESTIONS[current];
    const buttons = questionArea.querySelectorAll("[data-option]");

    buttons.forEach((button, index) => {
      button.disabled = true;
      if (index === item.answer) button.classList.add("correct");
      if (index === choice && choice !== item.answer) button.classList.add("wrong");
    });

    const isCorrect = choice === item.answer;
    applyScore(isCorrect);

    feedback.classList.add(isCorrect ? "good" : "bad");
    feedback.textContent = isCorrect
      ? "🎉 Betul! +100 markah"
      : `💡 Belum tepat! -50 markah. Jawapan betul: ${item.options[item.answer]}`;

    nextBtn.disabled = false;
  }

  function checkText() {
    if (answered) return;

    const input = $("#textAnswer");
    const value = normalise(input.value);

    if (!value) {
      feedback.className = "feedback bad";
      feedback.textContent = "⚠️ Sila tulis jawapan dahulu.";
      input.focus();
      return;
    }

    answered = true;
    input.disabled = true;
    $("#checkText").disabled = true;

    const item = QUESTIONS[current];
    const isCorrect = value === normalise(item.answer);
    applyScore(isCorrect);

    feedback.classList.add(isCorrect ? "good" : "bad");
    feedback.textContent = isCorrect
      ? "🌟 Hebat! +100 markah"
      : `💡 Jawapan tepat: ${item.answer} • -50 markah`;

    nextBtn.disabled = false;
  }

  function nextQuestion() {
    if (!answered) return;

    if (current < QUESTIONS.length - 1) {
      current++;
      renderQuestion();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      finishQuiz();
    }
  }

  function previousQuestion() {
    if (current > 0) {
      current--;
      renderQuestion();
    }
  }

  function updateTimer() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    timerEl.textContent =
      `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;

    timerEl.parentElement.style.background = timeLeft <= 60 ? "#fee2e2" : "#fff1f2";
    timerEl.parentElement.style.color = timeLeft <= 60 ? "#b91c1c" : "#dc2626";
  }

  function startTimer() {
    clearInterval(timerId);
    timerId = setInterval(() => {
      timeLeft--;
      updateTimer();

      if (timeLeft <= 0) {
        clearInterval(timerId);
        finishQuiz(true);
      }
    }, 1000);
  }

  function startQuiz() {
    player = studentName.value.trim();

    if (!player) {
      nameError.textContent = "⚠️ Sila masukkan nama sebelum mula.";
      studentName.focus();
      return;
    }

    nameError.textContent = "";
    current = 0;
    score = 0;
    correctCount = 0;
    stars = 0;
    timeLeft = 15 * 60;

    $("#studentGreeting").textContent = `Hai, ${player}! 🌈`;
    startScreen.classList.add("hidden");
    resultScreen.classList.add("hidden");
    quizScreen.classList.remove("hidden");

    updateTimer();
    renderQuestion();
    renderLeaderboard();
    startTimer();
  }

  function finishQuiz(timeUp = false) {
    clearInterval(timerId);

    const board = getBoard();
    board.push({ name: player, score });
    board.sort((a, b) => b.score - a.score);
    saveBoard(board);
    renderLeaderboard();

    quizScreen.classList.add("hidden");
    resultScreen.classList.remove("hidden");

    const percentage = correctCount / QUESTIONS.length;
    let title = "Teruskan Berusaha! 💪";
    let icon = "🌱";

    if (percentage >= 0.8) {
      title = "Cemerlang! 🏆";
      icon = "🏆";
    } else if (percentage >= 0.6) {
      title = "Bagus! 🌟";
      icon = "🌟";
    }

    $("#resultIcon").textContent = icon;
    $("#resultTitle").textContent = timeUp ? "Masa Tamat! ⏰" : title;
    $("#resultMessage").textContent =
      `${player}, kamu berjaya menamatkan kuiz dengan ${correctCount} daripada ${QUESTIONS.length} jawapan betul.`;

    $("#finalScore").textContent = score;
    $("#finalCorrect").textContent = `${correctCount}/${QUESTIONS.length}`;
    $("#finalStars").textContent = stars;
    $("#finalTime").textContent = `${String(Math.floor(timeLeft / 60)).padStart(2, "0")}:${String(timeLeft % 60).padStart(2, "0")}`;

    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function restart() {
    clearInterval(timerId);
    studentName.value = "";
    nameError.textContent = "";
    resultScreen.classList.add("hidden");
    quizScreen.classList.add("hidden");
    startScreen.classList.remove("hidden");
    studentName.focus();
  }

  $("#startBtn").addEventListener("click", startQuiz);
  studentName.addEventListener("keydown", event => {
    if (event.key === "Enter") startQuiz();
  });
  nextBtn.addEventListener("click", nextQuestion);
  prevBtn.addEventListener("click", previousQuestion);
  $("#againBtn").addEventListener("click", restart);

  renderLeaderboard();
  updateTimer();
})();
