# Kuiz Kata Majmuk Tahun 2

Permainan kuiz interaktif HTML + CSS + JavaScript untuk GitHub Pages.

## Fail
- `index.html` — halaman utama
- `style.css` — reka bentuk
- `script.js` — soalan, markah, pemasa dan papan pendahulu
- `nota-kata-majmuk.jpg` — nota bergambar yang dibekalkan

## Cara terbitkan di GitHub Pages
1. Cipta repository baharu di GitHub.
2. Muat naik semua fail ini ke repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`.
6. Klik **Save**.
7. GitHub akan memberikan URL Pages untuk dikongsi kepada murid.

## Nota penting tentang papan pendahulu
Versi ini ialah laman statik. Papan pendahulu menggunakan `localStorage`, jadi markah disimpan pada browser/peranti yang digunakan sahaja. Ia tidak menggabungkan markah semua murid di seluruh peranti.

Jika guru mahukan papan pendahulu global yang menerima markah semua murid secara masa nyata, permainan ini perlu disambungkan kepada pangkalan data seperti Firebase/Supabase.
